package kaiyuan.flappybird;

//游戏入口
public class GameStart {
    public static void main(String[] args) {
        new Game();
    }

}
